import {
  Meta,
  Error, Paging, Sorting,
} from '@modules/general/libraries/general-types';

export interface <FTName | pascalcase> {

}

export interface <FTName | pascalcase>DetailEntity {
  data: <FTName | pascalcase> | null | undefined;
  meta: Meta;
  status_code: string;
  object_type: string;
  time_taken: number;
  creation_date: string;
  url: string;
  message: string;
  error: Error | null;
  id: number;
}

export interface <FTName | pascalcase>ListEntity {
  data?: <FTName | pascalcase>[] | null | undefined;
  paging: Paging;
  sorting: Sorting[];
  meta: Meta;
  status_code: string;
  object_type: string;
  time_taken: number;
  creation_date: string;
  url: string;
  message: string;
  error: Error | null;
  criteria: <FTName | pascalcase>Criteria;
}

export interface <FTName | pascalcase>Criteria {
  limit: number;
  offset: number;
  sorting: Sorting[];
  searchKeywords: string | null | undefined;
}

export interface Get<FTName | pascalcase>ListAction {
  type: string;
  payload: Get<FTName | pascalcase>ListPayload;
}

export interface Get<FTName | pascalcase>ListPayload {
  criteria: <FTName | pascalcase>Criteria;
  accessToken: string;
}

export interface Put<FTName | pascalcase>ListAction {
  type: string;
  payload: Put<FTName | pascalcase>ListPayload;
}

export interface Put<FTName | pascalcase>ListPayload {
  criteria: <FTName | pascalcase>Criteria;
  <FTName | camelcase>ListEntity: <FTName | pascalcase>ListEntity;
}

export interface <FTName | pascalcase>StateList {
  [key: string]: <FTName | pascalcase>StateListItem;
}
export interface <FTName | pascalcase>StateListItem {
  items: <FTName | pascalcase>[] | null | undefined;
  paging: Paging;
  sorting: Sorting[] | undefined | null;
  criteria: <FTName | pascalcase>Criteria;
  pending: boolean;
  error: Error | null;
}

export interface Pending<FTName | pascalcase>ListAction {
  type: string;
  payload: Pending<FTName | pascalcase>ListPayload;
}

export interface Pending<FTName | pascalcase>ListPayload {
  pending: boolean;
  criteria: <FTName | pascalcase>Criteria;
}

export interface Error<FTName | pascalcase>ListAction {
  type: string;
  payload: Error<FTName | pascalcase>ListPayload;
}

export interface Error<FTName | pascalcase>ListPayload {
  error: Error | null;
  criteria: <FTName | pascalcase>Criteria;
}

export interface Get<FTName | pascalcase>DetailAction {
  type: string;
  payload: Get<FTName | pascalcase>DetailPayload;
}

export interface Get<FTName | pascalcase>DetailPayload {
  id: number;
  accessToken: string;
}

export interface Put<FTName | pascalcase>DetailAction {
  type: string;
  payload: Put<FTName | pascalcase>DetailPayload;
}

export interface Put<FTName | pascalcase>DetailPayload {
  id: number;
  <FTName | camelcase>Detail: <FTName | pascalcase>DetailEntity;
}

export interface <FTName | pascalcase>StateDetailItem {
  item: <FTName | pascalcase> | null | undefined;
  id: number;
  pending: boolean;
  error: Error | null;
}

export interface <FTName | pascalcase>StateDetail {
  [id: number]: <FTName | pascalcase>StateDetailItem;
}

export interface Pending<FTName | pascalcase>DetailAction {
  type: string;
  payload: Pending<FTName | pascalcase>DetailPayload;
}

export interface Pending<FTName | pascalcase>DetailPayload {
  id: number;
  pending: boolean;
}

export interface Error<FTName | pascalcase>DetailAction {
  type: string;
  payload: Error<FTName | pascalcase>DetailPayload;
}

export interface Error<FTName | pascalcase>DetailPayload {
  id: number;
  error: Error | null;
}
export interface <FTName | pascalcase>State {
  list: <FTName | pascalcase>StateList;
  detail: <FTName | pascalcase>StateDetail;
}
