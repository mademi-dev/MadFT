import {
  <FTName | pascalcase>Criteria,
  <FTName | pascalcase>ListEntity,
  Get<FTName | pascalcase>ListAction,
  Put<FTName | pascalcase>ListAction,
  Pending<FTName | pascalcase>ListAction,
  Error<FTName | pascalcase>ListAction,

  <FTName | pascalcase>DetailEntity,
  Get<FTName | pascalcase>DetailAction,
  Put<FTName | pascalcase>DetailAction,
  Pending<FTName | pascalcase>DetailAction,
  Error<FTName | pascalcase>DetailAction,
} from '@modules/<FTName | kebabcase>/libraries/<FTName | kebabcase>-types';
import { Error, } from '@modules/general/libraries/general-types';
import {
  REQUEST_<FTName | constantcase>_LIST,
  PUT_<FTName | constantcase>_LIST,
  PUT_PENDING_<FTName | constantcase>_LIST,
  PUT_ERROR_<FTName | constantcase>_LIST,

  REQUEST_<FTName | constantcase>_DETAIL,
  PUT_<FTName | constantcase>_DETAIL,
  PUT_PENDING_<FTName | constantcase>_DETAIL,
  PUT_ERROR_<FTName | constantcase>_DETAIL,
} from '../const/<FTName | kebabcase>-const';

export const get<FTName | pascalcase>List = (
  criteria: <FTName | pascalcase>Criteria,
  accessToken: string
): Get<FTName | pascalcase>ListAction => ({
  type: REQUEST_<FTName | constantcase>_LIST,
  payload: {
    criteria,
    accessToken,
  },
});

export const put<FTName | pascalcase>List = (
  criteria: <FTName | pascalcase>Criteria,
  <FTName | camelcase>ListEntity: <FTName | pascalcase>ListEntity
): Put<FTName | pascalcase>ListAction => ({
  type: PUT_<FTName | constantcase>_LIST,
  payload: {
    criteria,
    <FTName | camelcase>ListEntity,
  },
});

export const putPending<FTName | pascalcase>List = (
  pending: boolean,
  criteria: <FTName | pascalcase>Criteria
): Pending<FTName | pascalcase>ListAction => ({
  type: PUT_PENDING_<FTName | constantcase>_LIST,
  payload: {
    pending,
    criteria,
  },
});

export const putError<FTName | pascalcase>List = (
  error: Error,
  criteria: <FTName | pascalcase>Criteria
): Error<FTName | pascalcase>ListAction => ({
  type: PUT_ERROR_<FTName | constantcase>_LIST,
  payload: {
    error,
    criteria,
  },
});

export const get<FTName | pascalcase>Detail = (
  id: number,
  accessToken: string
): Get<FTName | pascalcase>DetailAction => ({
  type: REQUEST_<FTName | constantcase>_DETAIL,
  payload: {
    id,
    accessToken,
  },
});

export const put<FTName | pascalcase>Detail = (
  id: number,
  <FTName | camelcase>Detail: <FTName | pascalcase>DetailEntity
): Put<FTName | pascalcase>DetailAction => ({
  type: PUT_<FTName | constantcase>_DETAIL,
  payload: {
    id,
    <FTName | camelcase>Detail,
  },
});

export const putPending<FTName | pascalcase>Detail = (
  pending: boolean,
  id: number
): Pending<FTName | pascalcase>DetailAction => ({
  type: PUT_PENDING_<FTName | constantcase>_DETAIL,
  payload: {
    pending,
    id,
  },
});

export const putError<FTName | pascalcase>Detail = (
  error: Error,
  id: number
): Error<FTName | pascalcase>DetailAction => ({
  type: PUT_ERROR_<FTName | constantcase>_DETAIL,
  payload: {
    error,
    id,
  },
});
