import {
  put, call, take, fork,
} from 'redux-saga/effects';
import { Get<FTName | pascalcase>DetailPayload, <FTName | pascalcase>DetailEntity, } from '@modules/<FTName | kebabcase>/libraries/<FTName | kebabcase>-types';
import { fetch<FTName | pascalcase>Detail, } from '../api/<FTName | kebabcase>-api';
import {
  put<FTName | pascalcase>Detail,
  putPending<FTName | pascalcase>Detail,
  putError<FTName | pascalcase>Detail,
} from '../action/<FTName | kebabcase>-action';
import { REQUEST_<FTName | constantcase>_DETAIL, } from '../const/<FTName | kebabcase>-const';

function* <FTName | camelcase>DetailFlow({
  id, accessToken, 
}: Get<FTName | pascalcase>DetailPayload) {
  try {
    yield put(putPending<FTName | pascalcase>Detail(true, id));

    const <FTName | camelcase>Detail: <FTName | pascalcase>DetailEntity = yield call(fetch<FTName | pascalcase>Detail, id, accessToken);
    if (<FTName | camelcase>Detail !== null) {
      yield put(put<FTName | pascalcase>Detail(id, <FTName | camelcase>Detail));
      yield put(putPending<FTName | pascalcase>Detail(false, id));
    } else {
      yield put(
        putError<FTName | pascalcase>Detail({
          error_code: 500,
          error_message: 'Error fetching data.',
        }, id)
      );
      yield put(putPending<FTName | pascalcase>Detail(false, id));
    }
  } catch (error) {
    yield put(
      putError<FTName | pascalcase>Detail({
        error_code: 500,
        error_message: 'Error fetching data.',
      }, id)
    );
  }
}

function* <FTName | camelcase>DetailWatcher() {
  while (true) {
    const { payload, } = yield take(REQUEST_<FTName | constantcase>_DETAIL);
    yield fork(<FTName | camelcase>DetailFlow, payload);
  }
}

export default <FTName | camelcase>DetailWatcher;
