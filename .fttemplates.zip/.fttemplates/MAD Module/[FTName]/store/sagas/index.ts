import { all, } from 'redux-saga/effects';
import <FTName | camelcase>DetailWatcher from './<FTName | kebabcase>-detail-saga';
import <FTName | camelcase>ListWatcher from './<FTName | kebabcase>-list-saga';

function* <FTName | camelcase>Saga() {
  yield all([
    <FTName | camelcase>ListWatcher(),
    <FTName | camelcase>DetailWatcher(),
  ]);
}
export default <FTName | camelcase>Saga;
