import {
  take, put, call, fork,
} from 'redux-saga/effects';
import { Get<FTName | pascalcase>ListPayload, <FTName | pascalcase>ListEntity, } from '@modules/<FTName | kebabcase>/libraries/<FTName | kebabcase>-types';
import { fetch<FTName | pascalcase>List, } from '../api/<FTName | kebabcase>-api';
import {
  put<FTName | pascalcase>List, putPending<FTName | pascalcase>List, putError<FTName | pascalcase>List,
} from '../action/<FTName | kebabcase>-action';
import { REQUEST_<FTName | constantcase>_LIST, } from '../const/<FTName | kebabcase>-const';

function* <FTName | camelcase>ListFlow({
  criteria, accessToken, 
}: Get<FTName | pascalcase>ListPayload) {
  try {
    yield put(putPending<FTName | pascalcase>List(true, criteria));

    const <FTName | camelcase>ListEntity: <FTName | pascalcase>ListEntity = yield call(fetch<FTName | pascalcase>List, criteria, accessToken);
    if (<FTName | camelcase>ListEntity !== null) {
      yield put(put<FTName | pascalcase>List(criteria, <FTName | camelcase>ListEntity));
      yield put(putPending<FTName | pascalcase>List(false, criteria));
    } else {
      yield put(
        putError<FTName | pascalcase>List({
          error_code: 500,
          error_message: 'Error fetching data.',
        }, criteria)
      );
      yield put(putPending<FTName | pascalcase>List(false, criteria));
    }
  } catch (error) {
    yield put(
      putError<FTName | pascalcase>List({
        error_code: 500,
        error_message: 'Error fetching data.',
      }, criteria)
    );
  }
}

function* <FTName | camelcase>ListWatcher() {
  while (true) {
    const { payload, } = yield take(REQUEST_<FTName | constantcase>_LIST);
    yield fork(<FTName | camelcase>ListFlow, payload);
  }
}

export default <FTName | camelcase>ListWatcher;
