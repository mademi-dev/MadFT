import axios from 'axios';
import { API_KEY, API_DOMAIN, } from '@modules/general/libraries/constants';
import {} from '@modules/<FTName | kebabcase>/libraries/<FTName | kebabcase>-types';

import {
  <FTName | pascalcase>Criteria, <FTName | pascalcase>DetailEntity, <FTName | pascalcase>ListEntity,
} from '@modules/<FTName | kebabcase>/libraries/<FTName | kebabcase>-types';

export async function fetch<FTName | pascalcase>List(
  criteria: <FTName | pascalcase>Criteria,
  accessToken: string
): Promise<<FTName | pascalcase>ListEntity> {
  try {
    const {
      limit, offset, sorting, searchKeywords,
    } = criteria;

    const url = `${API_DOMAIN}/`;

    const response = await axios.get<any>(url, {
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        Authorization: `Bearer ${accessToken}`,
      },
    });
    if (response.data) {
      const list = response.data;
      return list;
    }
  } catch (error) {

  }
  return Promise.reject();
}

export async function fetch<FTName | pascalcase>Detail(
  id: number,
  accessToken: string
): Promise<<FTName | pascalcase>DetailEntity> {
  try {
    const url = `${API_DOMAIN}/`;

    const response = await axios.get<any>(url, {
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        Authorization: `Bearer ${accessToken}`,
      },
    });
    if (response) {
      const detail = response.data;
      return detail;
    }

  } catch (error) {

  }
  return Promise.reject();
}

