export const REQUEST_<FTName | constantcase>_DETAIL = 'REQUEST_<FTName | constantcase>_DETAIL';
export const PUT_<FTName | constantcase>_DETAIL = 'PUT_<FTName | constantcase>_DETAIL';
export const PUT_PENDING_<FTName | constantcase>_DETAIL = 'PUT_PENDING_<FTName | constantcase>_DETAIL';
export const PUT_ERROR_<FTName | constantcase>_DETAIL = 'PUT_ERROR_<FTName | constantcase>_DETAIL';


export const REQUEST_<FTName | constantcase>_LIST = 'REQUEST_<FTName | constantcase>_LIST';
export const PUT_<FTName | constantcase>_LIST = 'PUT_<FTName | constantcase>_LIST';
export const PUT_PENDING_<FTName | constantcase>_LIST = 'PUT_PENDING_<FTName | constantcase>_LIST';
export const PUT_ERROR_<FTName | constantcase>_LIST = 'PUT_ERROR_<FTName | constantcase>_LIST';

