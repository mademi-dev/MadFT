import hash from '@modules/general/libraries/hash';
import {
  Put<FTName | pascalcase>DetailPayload,
  Pending<FTName | pascalcase>DetailPayload,
  Error<FTName | pascalcase>DetailPayload,

  Put<FTName | pascalcase>ListPayload,
  Pending<FTName | pascalcase>ListPayload,
  Error<FTName | pascalcase>ListPayload,

  <FTName | pascalcase>State,
  <FTName | pascalcase>StateDetailItem,
  <FTName | pascalcase>StateListItem,
} from '@modules/<FTName | kebabcase>/libraries/<FTName | kebabcase>-types';

const init<FTName | pascalcase>State: <FTName | pascalcase>State = {
  list: {},
  detail: {},
};

function add<FTName | pascalcase>Detail(
  state: <FTName | pascalcase>State,
  payload: Put<FTName | pascalcase>DetailPayload
): <FTName | pascalcase>State {
  const {
    id,
    <FTName | camelcase>Detail,
  } = payload;

  const newItem: <FTName | pascalcase>StateDetailItem = {
    item: <FTName | camelcase>Detail.data,
    id,
    pending: false,
    error: null,
  };

  let result = { ...state.detail, };
  if (state.detail[id]) {
    result[id] = newItem;
  } else {
    result = {
      ...state.detail,
      ...{ [id]: newItem, },
    };
  }

  return {
    ...state,
    detail: { ...result, },
  };
}

function setPending<FTName | pascalcase>Detail(
  state: <FTName | pascalcase>State,
  payload: Pending<FTName | pascalcase>DetailPayload
): <FTName | pascalcase>State {
  const {
    pending,
    id,
  } = payload;

  const newItem: <FTName | pascalcase>StateDetailItem = {
    item: null,
    id,
    error: null,
    pending,
  };

  let result = { ...state.detail, };
  if (state.detail[id]) {
    result[id].pending = pending;
  } else {
    result = {
      ...state.detail,
      ...{ [id]: newItem, },
    };
  }

  return {
    ...state,
    detail: { ...result, },
  };
}

function setError<FTName | pascalcase>Detail(
  state: <FTName | pascalcase>State,
  payload: Error<FTName | pascalcase>DetailPayload
): <FTName | pascalcase>State {
  const {
    error,
    id,
  } = payload;

  const newItem: <FTName | pascalcase>StateDetailItem = {
    item: null,
    id,
    error,
    pending: false,
  };

  let result = { ...state.detail, };
  if (state.detail[id]) {
    result[id].error = error;
  } else {
    result = {
      ...state.detail,
      ...{ [id]: newItem, },
    };
  }

  return {
    ...state,
    detail: { ...result, },
  };
}

function add<FTName | pascalcase>List(
  state: <FTName | pascalcase>State,
  payload: Put<FTName | pascalcase>ListPayload
): <FTName | pascalcase>State {
  const {
    <FTName | camelcase>ListEntity,
    criteria,
  } = payload;

  const key = hash(criteria);
  const newList: <FTName | pascalcase>StateListItem = {
    items: <FTName | camelcase>ListEntity.data,
    paging: <FTName | camelcase>ListEntity.paging,
    sorting: <FTName | camelcase>ListEntity.sorting,
    criteria,
    pending: false,
    error: null,
  };

  let result = { ...state.list, };
  if (state.list[key]) {
    result[key] = newList;
  } else {
    result = {
      ...state.list,
      ...{ [`${key}`]: newList, },
    };
  }

  return {
    ...state,
    list: { ...result, },
  };
}

function setPending<FTName | pascalcase>List(
  state: <FTName | pascalcase>State,
  payload: Pending<FTName | pascalcase>ListPayload
): <FTName | pascalcase>State {
  const {
    pending,
    criteria,
  } = payload;

  const key = hash(criteria);
  const newList: <FTName | pascalcase>StateListItem = {
    items: [],
    paging: {
      offset: criteria.offset,
      limit: criteria.limit,
      total: 0,
      returned: 0,
      has_more: false,
    },
    sorting: [],
    criteria,
    error: null,
    pending,
  };

  let result = { ...state.list, };
  if (state.list[key]) {
    result[key].pending = pending;
  } else {
    result = {
      ...state.list,
      ...{ [`${key}`]: newList, },
    };
  }

  return {
    ...state,
    list: { ...result, },
  };
}

function setError<FTName | pascalcase>List(
  state: <FTName | pascalcase>State,
  payload: Error<FTName | pascalcase>ListPayload
): <FTName | pascalcase>State {
  const {
    error,
    criteria,
  } = payload;

  const key = hash(criteria);
  const newList: <FTName | pascalcase>StateListItem = {
    items: [],
    paging: {
      offset: criteria.offset,
      limit: criteria.limit,
      total: 0,
      returned: 0,
      has_more: false,
    },
    sorting: [],
    criteria,
    error,
    pending: false,
  };

  let result = { ...state.list, };
  if (state.list[key]) {
    result[key].error = error;
  } else {
    result = {
      ...state.list,
      ...{ [`${key}`]: newList, },
    };
  }

  return {
    ...state,
    list: { ...result, },
  };
}

export {
  init<FTName | pascalcase>State,
  add<FTName | pascalcase>Detail,
  setPending<FTName | pascalcase>Detail,
  setError<FTName | pascalcase>Detail,
  add<FTName | pascalcase>List,
  setPending<FTName | pascalcase>List,
  setError<FTName | pascalcase>List,
};
