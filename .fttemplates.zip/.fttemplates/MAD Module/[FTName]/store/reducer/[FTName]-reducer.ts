import { HYDRATE, } from 'next-redux-wrapper';
import { Reducer, } from 'redux';
import { AppAction, } from '@modules/general/libraries/utils';
import { <FTName | pascalcase>State, } from '@modules/<FTName | kebabcase>/libraries/<FTName | kebabcase>-types';
import {
  PUT_<FTName | constantcase>_DETAIL,
  PUT_PENDING_<FTName | constantcase>_DETAIL,
  PUT_ERROR_<FTName | constantcase>_DETAIL,
  PUT_<FTName | constantcase>_LIST,
  PUT_PENDING_<FTName | constantcase>_LIST,
  PUT_ERROR_<FTName | constantcase>_LIST,
} from '../const/<FTName | kebabcase>-const';
import {
  init<FTName | pascalcase>State,
  add<FTName | pascalcase>Detail,
  setPending<FTName | pascalcase>Detail,
  setError<FTName | pascalcase>Detail,
  add<FTName | pascalcase>List,
  setPending<FTName | pascalcase>List,
  setError<FTName | pascalcase>List,
} from './<FTName | kebabcase>-helper';

const <FTName | camelcase>Reducer: Reducer<<FTName | pascalcase>State, AppAction> = (
  state: <FTName | pascalcase>State = init<FTName | pascalcase>State,
  action: AppAction
): <FTName | pascalcase>State => {
  switch (action.type) {
    case HYDRATE:
      // Attention! This will overwrite client state! Real apps should use proper reconciliation.
      return {
        ...state, ...action.payload,
      };

    case PUT_<FTName | constantcase>_DETAIL:
      return add<FTName | pascalcase>Detail(state, action.payload);

    case PUT_PENDING_<FTName | constantcase>_DETAIL:
      return setPending<FTName | pascalcase>Detail(state, action.payload);

    case PUT_ERROR_<FTName | constantcase>_DETAIL:
      return setError<FTName | pascalcase>Detail(state, action.payload);

    case PUT_<FTName | constantcase>_LIST:
      return add<FTName | pascalcase>List(state, action.payload);

    case PUT_PENDING_<FTName | constantcase>_LIST:
      return setPending<FTName | pascalcase>List(state, action.payload);

    case PUT_ERROR_<FTName | constantcase>_LIST:
      return setError<FTName | pascalcase>List(state, action.payload);

    default:
      return { ...state, };
  }
};

export default <FTName | camelcase>Reducer;
