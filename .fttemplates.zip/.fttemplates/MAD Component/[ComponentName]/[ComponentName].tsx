import styles from './<ComponentName | kebabcase>.module.scss';

export default function <ComponentName | pascalcase>() {
    return <></>;
}