export default function <PageName | pascalcase>Page() {
    return null;
}